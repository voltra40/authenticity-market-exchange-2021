var Ame = artifacts.require("Ame");

module.exports = function(deployer) {
	deployer.deploy(Ame);
};